function [state, str] = parsave(filename, varargin)
    % Save variables in varargin with their own name to the file specified by filename
    % filename: filename (absolute or relative path), can be with or without extend name
    % varargin: variables to save. Pass variables but not variable names directly.
    % return:
    %   state: save state, 0: unsuccessful, 1:successful
    %   str: structure used to save file.
    %       str.msg: if state == 0, str will only have one field '''msg''', to tell which happened
    % !!!Update in 2024 Apr 26. IMPORTANT!!!
    % The last varargin can be a string array or cell array of character
    % vectors. If do so, the string will be used as the variable name to be
    % saved. The order is the same as you pass your variables in
    % varargin{1:end-1}.
    warning('off','MATLAB:MKDIR:DirectoryExists')
    if nargin == 1
        str.msg = "Expected at least 2 inputs. but got only 1. See the help document of parsave for more details";
        state = 0;
        return
    end

    if isstring(varargin{end}) || iscellstr(varargin{end})
        var_name = varargin{end};
        assert(length(var_name)==(nargin-2),"Specify as many variable names as save variables");
        var_name = string(var_name);
    else
        var_name = strings(nargin-1,1);
        for ii = 1:nargin-1
            var_name(ii) = inputname(ii+1);
        end
    end

    split_filename = split(filename,filesep);
    if length(split_filename) > 1
        mkdir(join(split_filename(1:end-1),filesep));
    end

    filename = char(filename);

    if ~strcmp(filename( end - 3:end), '.mat')
        filename = [filename, '.mat'];
    end

    try
        for ii = 1:length(var_name)
            str.(var_name(ii)) = varargin{ii};
        end

        save(filename, '-struct', 'str', "-mat");
        state = 1;
    catch ME
        str.msg = ME.message;
        state = 0;
    end

end
