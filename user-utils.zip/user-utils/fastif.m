function value = fastif(cond, t, f)
arguments (Input)
    cond 
    t
    f
end
arguments (Output)
    value
end
    if cond
        value = t;
    else
        value = f;
    end
end
