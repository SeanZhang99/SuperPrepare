function y = maxabs(x, varargin)
    y = max(abs(x), varargin{:});
end
