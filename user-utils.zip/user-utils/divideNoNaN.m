function division = divideNoNaN(numerator,denominator)
arguments (Input)
    numerator
    denominator
end
arguments (Output)
    division
end
%DIVIDENONAN Element-wise division, give 0 (not NaN) when denominator is 0
%   Detailed explanation goes here
    denominator(denominator==0) = Inf;
    division = numerator./denominator;
end

